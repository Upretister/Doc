import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TestGuardGuard implements CanActivate {
  // canActivate(
  //   next: ActivatedRouteSnapshot,
  //   state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
  //     console.log("working")
  //   return true;
  // }

  canActivate(route: ActivatedRouteSnapshot,routeSnap: RouterStateSnapshot): boolean {
      console.log("working")
      let demoId = route.paramMap.get('demoId');
      let demoId1 = routeSnap.root.params;
      console.log(demoId+" :: "+demoId1.demoId);
    return true;
  }
}
